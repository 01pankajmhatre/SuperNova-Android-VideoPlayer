// Copyright 2017 Archos SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.archos.mediacenter.video.browser.subtitlesmanager;

import android.content.Context;

import com.archos.mediacenter.video.R;
import com.archos.mediacenter.video.utils.VideoUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by vapillon on 18/05/15.
 */
public class ISO639codes {

    private static final Logger log = LoggerFactory.getLogger(ISO639codes.class);

    static public String generateTrackName(Context context, String string, String lang, String format, int disposition, boolean titleFirst) {
        String dispLabel = VideoUtils.getTrackDispositionLabel(context, disposition, titleFirst);
        String unknownTrackName = context.getText(R.string.unknown_track_name).toString();
        String langName = (lang != null && !lang.isEmpty()) ? getLanguageNameForLetterCode(context, lang) : "";

        String result = com.archos.mediacenter.utils.ISO639codes.generateTrackName(string, lang, langName, format, disposition, titleFirst, dispLabel, unknownTrackName);

        if (log.isDebugEnabled()) log.debug("generateTrackName: result={}", result);
        return result;
    }

    static public String generateTrackName(Context context, String string, String lang, String format, boolean titleFirst) {
        // generate track name as "title (language)" from lang XYZ or XY letter code
        String result = com.archos.mediacenter.utils.ISO639codes.generateTrackName(string, lang, format, titleFirst);
        if (result.startsWith("s_"))
            result =  VideoUtils.getLanguageString(context, result).toString();
        if (log.isDebugEnabled()) log.debug("generateTrackName: exception string={} result={}", string, result);
        if (result.isEmpty()) {
            result = context.getText(R.string.unknown_track_name).toString();
        }
        return result;
    }

    static public String replaceLanguageCodeInString(Context context, String string) {
        String result = com.archos.mediacenter.utils.ISO639codes.replaceLanguageCodeInString(string);
        if (result.startsWith("s_"))
            result =  VideoUtils.getLanguageString(context, result).toString();
        if (log.isDebugEnabled()) log.debug("replaceLanguageCodeInString: exception string={} result={}", string, result);
        return result;
    }

    static public String getLanguageNameForLetterCode(Context context, String code) {
        String result = com.archos.mediacenter.utils.ISO639codes.getLanguageNameForLetterCode(code);
        if (result.startsWith("s_"))
            return VideoUtils.getLanguageString(context, result).toString();
        else return result;
    }

    static public String getLanguageNameFor2LetterCode(Context context, String code) {
        String result = com.archos.mediacenter.utils.ISO639codes.getLanguageNameFor2LetterCode(code);
        if (result.startsWith("s_"))
            return VideoUtils.getLanguageString(context, result).toString();
        else return result;
    }

    static public String getLanguageNameOrStringFor2LetterCode(Context context, String code) {
        return com.archos.mediacenter.utils.ISO639codes.getLanguageNameFor2LetterCode(code);
    }

    static public String getLanguageNameFor3LetterCode(Context context, String code) {
        String result = com.archos.mediacenter.utils.ISO639codes.getLanguageNameFor3LetterCode(code);
        if (result.startsWith("s_"))
            return VideoUtils.getLanguageString(context, result).toString();
        else return result;
    }
}
