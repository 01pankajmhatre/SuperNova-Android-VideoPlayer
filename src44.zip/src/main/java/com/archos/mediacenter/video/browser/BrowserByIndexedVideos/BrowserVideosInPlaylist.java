// Copyright 2026 Courville Software
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.archos.mediacenter.video.browser.BrowserByIndexedVideos;

import android.database.Cursor;
import android.os.Bundle;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;

import com.archos.mediacenter.video.R;
import com.archos.mediacenter.video.browser.adapters.object.Video;
import com.archos.mediacenter.video.browser.loader.VideosSelectionInPlaylistLoader;
import com.archos.mediacenter.video.utils.VideoPreferencesCommon;
import com.archos.mediaprovider.video.VideoStore;
import com.archos.mediascraper.BaseTags;
import com.archos.mediascraper.EpisodeTags;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BrowserVideosInPlaylist extends BrowserByVideoSelection {

	private static final boolean DBG = false;
    private static final String TAG = "BrowserVideosInPlaylist";

	public static final String EXTRA_PLAYLIST_ID = "extra_playlist_id";
	public static final String EXTRA_MAP_MOVIES = "extra_map_movies";
	public static final String EXTRA_MAP_EPISODES = "extra_map_episodes";
	private Map<String, List<String>> mMoviesMap = new HashMap<>();
	private Map<String, List<String>> mEpisodesMap = new HashMap<>();

	protected long getPlaylistId() {
		return getArguments().getLong(EXTRA_PLAYLIST_ID);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//parsing maps
		String moviesMap = getArguments().getString(EXTRA_MAP_MOVIES);
		if(moviesMap != null) {
			for (String movie : moviesMap.split(",")) {
				String id = movie.split(":")[0];
				if (mMoviesMap.get(id) == null) {
					mMoviesMap.put(id, new ArrayList<String>());
				}
				mMoviesMap.get(id).add(movie.split(":")[1]);
			}
		}

		String episodeMap = getArguments().getString(EXTRA_MAP_EPISODES);
		if(episodeMap != null) {
			for (String episode : episodeMap.split(",")) {
				String id = episode.split(":")[0];
				if (mEpisodesMap.get(id) == null) {
					mEpisodesMap.put(id, new ArrayList<String>());
				}
				mEpisodesMap.get(id).add(episode.split(":")[1]);
			}
		}
	}
	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args2) {
		if (getArguments() != null) {
			String listOfMoviesIds = getArguments().getString(BrowserByVideoSelection.LIST_OF_IDS);
			if (listOfMoviesIds != null)
				return new VideosSelectionInPlaylistLoader(getContext(), listOfMoviesIds).getV4CursorLoader(true, mPreferences.getBoolean(VideoPreferencesCommon.KEY_HIDE_WATCHED, false));
		}
		return null;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		AdapterView.AdapterContextMenuInfo info;
		try {
			info = (AdapterView.AdapterContextMenuInfo) menuInfo;
		} catch (ClassCastException e) {
			Log.e(TAG, "bad menuInfo", e);
			return;
		}
		// This can be null sometimes, don't crash...
		if (info == null) {
			Log.e(TAG, "bad menuInfo");
			return;
		}

		final int position = info.position;

		menu.add(0, R.string.remove_from_list, 0, R.string.remove_from_list);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		if(!super.onContextItemSelected(item)){
			int index = item.getItemId();
			if(index == R.string.remove_from_list){
				AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
				Video video = mAdapterByVideoObjects.getVideoItem(info.position);
				BaseTags metadata = video.getFullScraperTags(getContext());
				boolean isEpisode = metadata instanceof EpisodeTags;
				VideoStore.VideoList.VideoItem videoItem  = new VideoStore.VideoList.VideoItem(-1,!isEpisode?(int)metadata.getOnlineId():-1, isEpisode?(int)metadata.getOnlineId():-1, VideoStore.List.SyncStatus.STATUS_DELETED);
				getContext().getContentResolver().update(VideoStore.List.getListUri(getArguments().getLong(EXTRA_PLAYLIST_ID)), videoItem.toContentValues(),  videoItem.getDBWhereString(), videoItem.getDBWhereArgs());
				//manually remove id
				String ids = getArguments().getString(BrowserByVideoSelection.LIST_OF_IDS);
				if(isEpisode){
					for(String itemId : mEpisodesMap.get(""+metadata.getOnlineId())){
						//remove all indexes
						ids = ids.replace(","+itemId,"");
						ids = ids.replace(itemId+",","");
						ids = ids.replace(itemId,"");
					}
				} else{
					for(String itemId : mMoviesMap.get(""+metadata.getOnlineId())){
						//remove all indexes
						ids = ids.replace(","+itemId,"");
						ids = ids.replace(itemId+",","");
						ids = ids.replace(itemId,"");
					}
				}
				getArguments().putString(BrowserByVideoSelection.LIST_OF_IDS, ids);
				LoaderManager.getInstance(this).restartLoader(0, null, this);
				return true;
			}
			else{
				return false;
			}
		}else return true;
	}
}
