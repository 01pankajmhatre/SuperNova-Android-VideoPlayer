// Copyright 2017 Archos SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.archos.mediacenter.video.leanback.tvshow;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.leanback.app.DetailsFragmentWithLessTopOffset;
import androidx.leanback.widget.ArrayObjectAdapter;
import androidx.leanback.widget.ClassPresenterSelector;
import androidx.leanback.widget.DetailsOverviewRow;
import androidx.leanback.widget.FullWidthDetailsOverviewRowPresenter;
import androidx.leanback.widget.FullWidthDetailsOverviewSharedElementHelper;
import androidx.leanback.widget.HeaderItem;
import androidx.leanback.widget.ItemAlignmentFacet;
import androidx.leanback.widget.ListRow;
import androidx.leanback.widget.ListRowPresenter;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.Presenter;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowPresenter;
import androidx.core.content.ContextCompat;
import androidx.palette.graphics.Palette;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.archos.mediacenter.video.R;
import com.archos.mediacenter.video.info.VideoInfoCommonClass;
import com.archos.mediacenter.video.utils.ThemeManager;
import com.archos.mediacenter.video.leanback.DetailsBackdropController;
import com.archos.mediacenter.video.leanback.adapter.object.WebPageLink;
import com.archos.mediacenter.video.leanback.details.ArchosDetailsOverviewRowPresenter;
import com.archos.mediacenter.video.leanback.details.BackgroundColorPresenter;
import com.archos.mediacenter.video.leanback.details.CastRow;
import com.archos.mediacenter.video.leanback.details.CastRowPresenter;
import com.archos.mediacenter.video.leanback.details.PlotAndGenresRow;
import com.archos.mediacenter.video.leanback.details.PlotAndGenresRowPresenter;
import com.archos.mediacenter.video.leanback.overlay.Overlay;
import com.archos.mediacenter.video.leanback.presenter.ScraperImageBackdropPresenter;
import com.archos.mediacenter.video.leanback.presenter.ScraperImagePosterPresenter;
import com.archos.mediacenter.video.utils.WebUtils;
import com.archos.mediascraper.ScraperImage;
import com.archos.mediascraper.ShowTags;
import com.archos.mediascraper.TagsFactory;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class TvshowMoreDetailsFragment extends DetailsFragmentWithLessTopOffset {

    private static final String TAG = "TvshowMoreDetails";

    public static final String EXTRA_TVSHOW_ID = "TVSHOW_ID";
    public static final String EXTRA_TVSHOW_WATCHED = "TVSHOW_WATCHED";
    public static final String SHARED_ELEMENT_NAME = "hero";

    /** The show we're displaying */
    private long mShowId;
    private boolean mShowWatched;

    /** all the data about this show in the DB */
    private ShowTags mShowTags;

    private DetailsOverviewRow mDetailsRow;
    private PlotAndGenresRow mPlotAndGenresRow;
    private CastRow mCastRow;
    private ListRow mPostersRow;
    private ListRow mBackdropsRow;
    private ListRow mWebLinksRow;
    private ArrayObjectAdapter mRowsAdapter;

    private DetailsBackdropController mBackdropController;

    public DetailsBackdropController getBackdropController() {
        return mBackdropController;
    }
    private FullScraperTagsTask mFullScraperTagsTask;
    private BuildRowsTask mBuildRowsTask;
    private ShowPosterSaverTask mShowPosterSaverTask;
    private BackdropSaverTask mBackdropSaverTask;

    private Overlay mOverlay;
    private ArchosDetailsOverviewRowPresenter mOverviewRowPresenter;
    private TvshowMoreDetailsDescriptionPresenter mDescriptionPresenter;
    private int mColor;
    private static int dominantColor = 0;
    private Handler mHandler;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTopOffsetRatio(0.6f);

        final Intent intent = getActivity().getIntent();
        mShowId = intent.getLongExtra(EXTRA_TVSHOW_ID, -1);
        mShowWatched = intent.getBooleanExtra(EXTRA_TVSHOW_WATCHED, false);
        mColor = ThemeManager.getInstance(getActivity()).getDetailsPrimaryColor();
        mHandler = new Handler(Looper.getMainLooper());
        mDescriptionPresenter = new TvshowMoreDetailsDescriptionPresenter(mShowWatched);
        mOverviewRowPresenter = new ArchosDetailsOverviewRowPresenter(mDescriptionPresenter, true);
        //be aware of a hack to avoid fullscreen overview : cf onSetRowStatus
        FullWidthDetailsOverviewSharedElementHelper helper = new FullWidthDetailsOverviewSharedElementHelper();
        helper.setSharedElementEnterTransition(getActivity(), SHARED_ELEMENT_NAME, 1000);
        mOverviewRowPresenter.setListener(helper);
        mOverviewRowPresenter.setBackgroundColor(ThemeManager.getInstance(getActivity()).getDetailsPrimaryColor());
        mOverviewRowPresenter.setOnActionClickedListener(null);

        setOnItemViewClickedListener(new OnItemViewClickedListener() {
            @Override
            public void onItemClicked(Presenter.ViewHolder itemViewHolder, Object item, RowPresenter.ViewHolder rowViewHolder, Row row) {
                if (item instanceof ScraperImage) {
                    if (row == mPostersRow) {
                        mShowPosterSaverTask = new ShowPosterSaverTask();
                    mShowPosterSaverTask.execute((ScraperImage) item);
                    }
                    else if (row == mBackdropsRow) {
                        mBackdropSaverTask = new BackdropSaverTask();
                        mBackdropSaverTask.execute((ScraperImage) item);
                    }
                }
                else if (item instanceof WebPageLink) {
                    WebPageLink link = (WebPageLink)item;
                    WebUtils.openWebLink(getActivity(), link.getUrl());
                }
            }
        });

        mBackdropController = new DetailsBackdropController(getActivity(), R.id.details_backdrop,
                VideoInfoCommonClass.getDarkerColor(mColor));
        mBackdropController.attach();
    }

    @Override
    protected void setupDetailsOverviewRowPresenter(FullWidthDetailsOverviewRowPresenter presenter) {
        ItemAlignmentFacet facet = new ItemAlignmentFacet();
        // by default align details_frame to half window height
        ItemAlignmentFacet.ItemAlignmentDef alignDef1 = new ItemAlignmentFacet.ItemAlignmentDef();
        alignDef1.setItemAlignmentViewId(R.id.details_frame);
        alignDef1.setItemAlignmentOffset(- getResources()
                .getDimensionPixelSize(R.dimen.lb_details_v2_align_pos_for_actions)
                - getResources().getDimensionPixelSize(R.dimen.lb_details_v2_actions_height));
        alignDef1.setItemAlignmentOffsetPercent(0);
        // when description is selected, keep details_frame aligned with actions position
        ItemAlignmentFacet.ItemAlignmentDef alignDef2 = new ItemAlignmentFacet.ItemAlignmentDef();
        alignDef2.setItemAlignmentViewId(R.id.details_frame);
        alignDef2.setItemAlignmentFocusViewId(R.id.details_overview_description);
        alignDef2.setItemAlignmentOffset(- getResources()
                .getDimensionPixelSize(R.dimen.lb_details_v2_align_pos_for_actions)
                - getResources().getDimensionPixelSize(R.dimen.lb_details_v2_actions_height));
        alignDef2.setItemAlignmentOffsetPercent(0);
        ItemAlignmentFacet.ItemAlignmentDef[] defs =
                new ItemAlignmentFacet.ItemAlignmentDef[] {alignDef1, alignDef2};
        facet.setAlignmentDefs(defs);
        presenter.setFacet(ItemAlignmentFacet.class, facet);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mOverlay = new Overlay(this);
    }

    @Override
    public void onDestroyView() {
        mOverlay.destroy();
        super.onDestroyView();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        // Cancel all the async tasks
        mBackdropController.onStop(mShowTags != null, mShowTags);
        if (mFullScraperTagsTask != null) mFullScraperTagsTask.cancel();
        if (mBuildRowsTask != null) mBuildRowsTask.cancel();
        if (mShowPosterSaverTask != null) mShowPosterSaverTask.cancel();
        if (mBackdropSaverTask != null) mBackdropSaverTask.cancel();
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        mOverlay.resume();
        mBackdropController.restoreIfNeeded();

        // Start loading the detailed info about the show if needed
        if (mShowTags==null) {
            mFullScraperTagsTask = new FullScraperTagsTask();
            mFullScraperTagsTask.execute(mShowId);
        }

        if (mShowTags != null) mBackdropController.loadIfIdle(mShowTags);
    }

    @Override
    public void onPause() {
        super.onPause();
        mOverlay.pause();
    }

    //--------------------------------------------

    /** Get the ShowTags */
    private class FullScraperTagsTask {
        private final ExecutorService executor = Executors.newSingleThreadExecutor();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private volatile boolean isCancelled = false;

        void execute(long showId) {
            executor.execute(() -> {
                ShowTags result = null;
                try {
                    if (isCancelled || Thread.currentThread().isInterrupted()) return;
                    result = TagsFactory.buildShowTags(getActivity(), showId);
                } catch (Exception e) {
                    Log.e(TAG, "FullScraperTagsTask failed", e);
                } finally {
                    executor.shutdown();
                }
                if (isCancelled) return;
                final ShowTags finalResult = result;
                handler.post(() -> {
                    if (isCancelled) return;
                    mShowTags = finalResult;

                    mBackdropController.loadIfIdle(finalResult);

                    // Build and load the rows
                    if (mBuildRowsTask != null) {
                        mBuildRowsTask.cancel();
                    }
                    mBuildRowsTask = new BuildRowsTask();
                    mBuildRowsTask.execute(mShowTags);
                });
            });
        }

        void cancel() {
            isCancelled = true;
            executor.shutdownNow();
        }
    }

    private class BuildRowsTask {
        private final ExecutorService executor = Executors.newSingleThreadExecutor();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private volatile boolean isCancelled = false;

        void execute(ShowTags showTags) {
            executor.execute(() -> {
                try {
                    if (isCancelled || Thread.currentThread().isInterrupted()) return;
                    ShowTags tags = showTags;

                    // Details ---------------
                    mDetailsRow = new DetailsOverviewRow(tags);
                    Bitmap bitmap = null;
                    try {
                        if (tags.getDefaultPoster() != null) {
                            // Poster
                            File file = tags.getDefaultPoster().getLargeFileF();
                            if (file != null) {
                                bitmap = Picasso.get()
                                        .load(file)
                                        .noFade() // no fade since we are using activity transition anyway
                                        .config(Bitmap.Config.ARGB_8888)
                                        .transform(new com.archos.mediacenter.video.picasso.FidelityTransformation(
                                                getResources().getDimensionPixelSize(R.dimen.details_poster_width),
                                                getResources().getDimensionPixelSize(R.dimen.details_poster_height)))
                                        .get();
                            }
                        }
                    } catch (IOException e) {
                        Log.d(TAG, "TvshowMoreDetailsFragment Picasso load exception", e);
                    } catch (NullPointerException e) { // getDefaultPoster() may return null (seen once at least)
                        Log.d(TAG, "TvshowMoreDetailsFragment doInBackground exception", e);
                    } finally {
                        if (bitmap != null) {
                            Palette palette = Palette.from(bitmap).generate();
                            if (palette.getDarkVibrantSwatch() != null)
                                mColor = palette.getDarkVibrantSwatch().getRgb();
                            else if (palette.getDarkMutedSwatch() != null)
                                mColor = palette.getDarkMutedSwatch().getRgb();
                            else
                                mColor = ThemeManager.getInstance(getActivity()).getDetailsPrimaryColor();
                            dominantColor = mColor;
                            mDetailsRow.setImageBitmap(getActivity(), bitmap);
                            mDetailsRow.setImageScaleUpAllowed(true);
                        }
                        else {
                            mDetailsRow.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.filetype_new_video));
                            mDetailsRow.setImageScaleUpAllowed(false);
                        }
                    }

                    // Plot and cast
                    if (tags.getPlot()!=null) {
                        mPlotAndGenresRow = new PlotAndGenresRow(getString(R.string.scrap_plot), tags.getPlot(), tags.getGenresFormatted(getActivity()));
                    } else {
                        mPlotAndGenresRow = null;
                    }

                    if (tags.getActorsFormatted()!=null) {
                        mCastRow = new CastRow(getString(R.string.scrap_cast), tags, "");
                    }
                    else {
                        mCastRow = null;
                    }

                    if (isCancelled) return;

                    // Posters
                    List<ScraperImage> posters = tags.getAllPostersInDb(getActivity());
                    if (!posters.isEmpty()) {
                        ArrayObjectAdapter postersRowAdapter = new ArrayObjectAdapter(new ScraperImagePosterPresenter());
                        postersRowAdapter.addAll(0, posters);
                        mPostersRow = new ListRow( new HeaderItem(getString(R.string.leanback_posters_header)), postersRowAdapter);
                    } else {
                        mPostersRow = null;
                    }

                    if (isCancelled) return;

                    // Backdrops
                    List<ScraperImage> backdrops = tags.getAllBackdropsInDb(getActivity());
                    if (!backdrops.isEmpty()) {
                        ArrayObjectAdapter backdropsRowAdapter = new ArrayObjectAdapter(new ScraperImageBackdropPresenter());
                        backdropsRowAdapter.addAll(0, backdrops);
                        mBackdropsRow = new ListRow( new HeaderItem(getString(R.string.leanback_backdrops_header)), backdropsRowAdapter);
                    } else {
                        mBackdropsRow = null;
                    }

                    // Web links
                    /*
                    final String imdbId = tags.getImdbId();
                    if ((imdbId!=null) && (imdbId.length()>0)) {
                        final String imdbUrl = getResources().getString(R.string.imdb_title_url) + imdbId;
                        ArrayObjectAdapter rowAdapter = new ArrayObjectAdapter(new WebPageLinkPresenter());
                        rowAdapter.add(new WebPageLink(imdbUrl));
                        mWebLinksRow = new ListRow( new HeaderItem(getString(R.string.leanback_weblinks_header)), rowAdapter);
                    } else {
                        mWebLinksRow = null;
                    }*/
                    mWebLinksRow = null; // No web links for now to be sure to get "leanback certification"
                } catch (Exception e) {
                    Log.e(TAG, "BuildRowsTask failed", e);
                } finally {
                    executor.shutdown();
                }
                if (isCancelled) return;
                handler.post(() -> {
                    if (isCancelled) return;
                    ClassPresenterSelector ps = new ClassPresenterSelector();
                    ps.addClassPresenter(DetailsOverviewRow.class, mOverviewRowPresenter);
                    ps.addClassPresenter(PlotAndGenresRow.class, new PlotAndGenresRowPresenter(14,mColor)); // 14 lines max to fit on screen
                    ps.addClassPresenter(CastRow.class, new CastRowPresenter(17,mColor)); // 17 lines max to fit on screen
                    ps.addClassPresenter(ListRow.class, new ListRowPresenter());
                    mOverviewRowPresenter.updateBackgroundColor(mColor);
                    mRowsAdapter = new ArrayObjectAdapter(ps);
                    mRowsAdapter.clear();
                    // Add all the non-null rows
                    for (Row row : new Row[] {mDetailsRow, mPlotAndGenresRow, mCastRow, mPostersRow, mBackdropsRow, mWebLinksRow}) {
                        if (row!=null) {
                            mRowsAdapter.add(row);
                        }
                    }
                    setAdapter(mRowsAdapter);
                });
            });
        }

        void cancel() {
            isCancelled = true;
            executor.shutdownNow();
        }
    }


    /** Saves a Poster as default poster for a show and update the current poster */
    private class ShowPosterSaverTask {
        private final ExecutorService executor = Executors.newSingleThreadExecutor();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private volatile boolean isCancelled = false;

        void execute(ScraperImage poster) {
            executor.execute(() -> {
                Bitmap result = null;
                try {
                    if (isCancelled || Thread.currentThread().isInterrupted()) return;
                    // Save in DB and download
                    if (poster.setAsDefault(getActivity(), -1)) { // -1 means for the whole show (not for a given season)
                        poster.download(getActivity());
                    }
                    // Update the bitmap
                    int width = getResources().getDimensionPixelSize(R.dimen.details_poster_width);
                    int height = getResources().getDimensionPixelSize(R.dimen.details_poster_height);
                    try {
                        result = Picasso.get()
                                .load(poster.getLargeFileF())
                                .noFade()
                                .config(Bitmap.Config.ARGB_8888)
                                .resize((int)(width * 2.0f), (int)(height * 2.0f))
                                .centerCrop()
                                .onlyScaleDown()
                                .transform(new com.archos.mediacenter.video.picasso.FidelityTransformation(width, height))
                                .get();
                    } catch (IOException e) {
                        Log.d(TAG, "ShowPosterSaverTask Picasso load exception", e);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "ShowPosterSaverTask failed", e);
                } finally {
                    executor.shutdown();
                }
                if (isCancelled) return;
                final Bitmap finalResult = result;
                handler.post(() -> {
                    if (isCancelled) return;
                    if (finalResult != null) {
                        mDetailsRow.setImageBitmap(getActivity(), finalResult);
                        mDetailsRow.setImageScaleUpAllowed(true);

                        Palette palette = Palette.from(finalResult).generate();
                        int color;

                        if (palette.getDarkVibrantSwatch() != null)
                            color = palette.getDarkVibrantSwatch().getRgb();
                        else if (palette.getDarkMutedSwatch() != null)
                            color = palette.getDarkMutedSwatch().getRgb();
                        else
                            color = ThemeManager.getInstance(getActivity()).getDetailsPrimaryColor();

                        if (color != mColor) {
                            mColor = color;

                            mOverviewRowPresenter.updateBackgroundColor(color);

                            for (Presenter pres : mRowsAdapter.getPresenterSelector().getPresenters()){
                                if (pres instanceof BackgroundColorPresenter)
                                    ((BackgroundColorPresenter) pres).setBackgroundColor(color);
                            }
                        }

                        Toast.makeText(getActivity(), R.string.leanback_poster_changed, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), R.string.error, Toast.LENGTH_SHORT).show();
                    }

                    // The activity result is set to OK if the poster or backdrop is changed
                    getActivity().setResult(Activity.RESULT_OK);
                });
            });
        }

        void cancel() {
            isCancelled = true;
            executor.shutdownNow();
        }
    }

    /** Saves a Backdrop as default for a video and update the current backdrop */
    private class BackdropSaverTask {
        private final ExecutorService executor = Executors.newSingleThreadExecutor();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private volatile boolean isCancelled = false;

        void execute(ScraperImage backdrop) {
            executor.execute(() -> {
                ShowTags result = null;
                try {
                    if (isCancelled || Thread.currentThread().isInterrupted()) return;
                    // Save in DB and download
                    if (backdrop.setAsDefault(getActivity())) {
                        backdrop.download(getActivity());
                    }
                    // Simplier to rebuild the full ShowTags here in order for the BackdropTask to get the new backdrop in it
                    result = TagsFactory.buildShowTags(getActivity(), mShowId);
                } catch (Exception e) {
                    Log.e(TAG, "BackdropSaverTask failed", e);
                } finally {
                    executor.shutdown();
                }
                if (isCancelled) return;
                final ShowTags finalResult = result;
                handler.post(() -> {
                    if (isCancelled) return;
                    mShowTags = finalResult;

                    mBackdropController.replace(mShowTags);
                    Toast.makeText(getActivity(), R.string.leanback_backdrop_changed, Toast.LENGTH_SHORT).show();

                    // The activity result is set to OK if the poster or backdrop is changed
                    getActivity().setResult(Activity.RESULT_OK);
                });
            });
        }

        void cancel() {
            isCancelled = true;
            executor.shutdownNow();
        }
    }

    public int getColor() {
        return mColor != 0 ? mColor : dominantColor;
    }

    public static int getDominantColor() {
        return dominantColor;
    }

}
