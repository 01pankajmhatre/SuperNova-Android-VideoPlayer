// Copyright 2026 Courville Software
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.archos.mediacenter.video.browser.BrowserByIndexedVideos.lists;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.archos.mediacenter.video.R;
import com.archos.mediacenter.video.browser.adapters.object.Video;
import com.archos.mediacenter.video.browser.loader.ListsLoader;
import com.archos.mediaprovider.video.VideoStore;
import com.archos.mediascraper.BaseTags;
import com.archos.mediascraper.EpisodeTags;

/**
 * Created by alexandre on 16/05/17.
 */

public class ListDialog extends DialogFragment {
    public static final String EXTRA_VIDEO = "video";
    private Video mVideo;
    private Adapter mAdapter;

    private class Adapter extends CursorAdapter{

        private final int mTitleIndex;

        public Adapter(Context context, Cursor c, boolean autoRequery) {
            super(context, c, autoRequery);
            mTitleIndex = getCursor().getColumnIndex(VideoStore.List.Columns.TITLE);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
            TextView tv = (TextView) LayoutInflater.from(getContext()).inflate(R.layout.browser_item_list_text, null);
            return tv;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(position<getCount()-1)
                return super.getView(position, convertView, parent);
            else {
                if(convertView == null)
                    convertView = newView(getContext(), getCursor(), parent);
                bindView(convertView,getContext(),null);
                return convertView;
            }
        }

        @Override
        public int getCount(){
            return super.getCount()+1;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            if(cursor==null)
                ((TextView)view).setText(R.string.create_new_list);
            else
                ((TextView)view).setText(cursor.getString(mTitleIndex));
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (getArguments() != null) {
            if (Build.VERSION.SDK_INT >= 33) {
                mVideo = getArguments().getSerializable(EXTRA_VIDEO, Video.class);
            } else {
                mVideo = (Video) getArguments().getSerializable(EXTRA_VIDEO);
            }
        }
        return getAlertDialog();
    }

    private AlertDialog getAlertDialog(){
        return new AlertDialog.Builder(getActivity()).setAdapter(getAdapter(), getOnClickListener()).create();
    }

    private DialogInterface.OnClickListener getOnClickListener() {
        return new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(i==mAdapter.getCount()-1){
                    //add new list
                    NewListDialog listDialog = new NewListDialog();
                    listDialog.setArguments(getArguments());
                    listDialog.show(getParentFragmentManager(), "");
                }
                else{
                    // use the clicked position: the cursor is left on whatever row was bound last, which is not
                    // necessarily the clicked one
                    long id = mAdapter.getItemId(i);
                    if (id <= 0) return;
                    BaseTags metadata = mVideo.getFullScraperTags(getActivity());
                    boolean isEpisode = metadata instanceof EpisodeTags;
                    VideoStore.VideoList.VideoItem videoItem  =
                            new VideoStore.VideoList.VideoItem(-1,!isEpisode?(int)metadata.getOnlineId():-1, isEpisode?(int)metadata.getOnlineId():-1, VideoStore.List.SyncStatus.STATUS_NOT_SYNC);
                    getActivity().getContentResolver().insert(VideoStore.List.getListUri(id), videoItem.toContentValues());

                }
            }
        };
    }

    private Adapter getAdapter() {

        mAdapter = new Adapter(getContext(), new ListsLoader(getContext()).loadInBackground(), true);
        return mAdapter;
    }
}
