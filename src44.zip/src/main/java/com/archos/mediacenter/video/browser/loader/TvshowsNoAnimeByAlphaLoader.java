// Copyright 2021 Courville Software
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.archos.mediacenter.video.browser.loader;

import android.content.Context;

public class TvshowsNoAnimeByAlphaLoader extends TvshowsNoAnimeByLoader {

    public static final String DEFAULT_SORT = COLUMN_SUBSET_NAME+" COLLATE LOCALIZED ASC";

    public TvshowsNoAnimeByAlphaLoader(Context context) {
        super(context);
        mSortOrder = DEFAULT_SORT;
        setSelection(getSelection(context));
    }

    public TvshowsNoAnimeByAlphaLoader(Context context, String sortOrder) {
        super(context);
        mSortOrder = sortOrder;
        setSelection(getSelection(context));
    }

    public String getSelection(Context context) {
        String col = com.archos.mediacenter.video.utils.SortUtils.getAlphaBucketColumn(context, com.archos.mediacenter.video.utils.SortUtils.SortScope.SHOW);
        return "SELECT\n" +
                "    UNICODE(SUBSTR(" + col + ",1,1)) AS _id,\n" +
                "    UPPER(SUBSTR(" + col + ",1,1)) AS name,\n" +
                "    group_concat( s_id ) AS list,\n" +
                "    group_concat( s_po_large_file ) AS po_file_list,\n" +
                "    count( s_id ) AS number\n" +
                "FROM  ( \n" +
                "  SELECT s_id, s_po_large_file, s_name, " + col + " FROM video\n"+
                "  WHERE s_id IS NOT NULL AND " + col + " IS NOT NULL"+ getCommonSelection()+"\n"+
                "  GROUP BY " + col + " COLLATE LOCALIZED\n" +
                ") \n" +
                "GROUP BY name\n" +
                " ORDER BY " + mSortOrder;
    }
}
