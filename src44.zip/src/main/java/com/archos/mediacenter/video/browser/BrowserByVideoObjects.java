// Copyright 2017 Archos SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


package com.archos.mediacenter.video.browser;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;

import com.archos.environment.ArchosIntents;
import com.archos.environment.ArchosSettings;
import com.archos.filecorelibrary.FileUtils;
import com.archos.mediacenter.utils.MediaUtils;
import com.archos.mediacenter.utils.videodb.VideoDbInfo;
import com.archos.mediacenter.utils.videodb.XmlDb;
import com.archos.mediacenter.video.CustomApplication;
import com.archos.mediacenter.video.R;
import com.archos.mediacenter.video.browser.BrowserByIndexedVideos.lists.ListDialog;
import com.archos.mediacenter.video.browser.adapters.AdapterByVideoObjectsInterface;
import com.archos.mediacenter.video.browser.adapters.PresenterAdapterInterface;
import com.archos.mediacenter.video.browser.adapters.object.Episode;
import com.archos.mediacenter.video.browser.adapters.object.Movie;
import com.archos.mediacenter.video.browser.adapters.object.NonIndexedVideo;
import com.archos.mediacenter.video.browser.adapters.object.Video;
import com.archos.mediacenter.video.browser.filebrowsing.network.BrowserByNetwork;
import com.archos.mediacenter.video.browser.presenter.CommonPresenter;
import com.archos.mediacenter.video.browser.presenter.ScrapedVideoDetailedPresenter;
import com.archos.mediacenter.video.browser.presenter.VideoGridPresenter;
import com.archos.mediacenter.video.browser.presenter.VideoGridShortPresenter;
import com.archos.mediacenter.video.browser.presenter.VideoListPresenter;
import com.archos.mediacenter.video.info.VideoInfoActivity;
import com.archos.mediacenter.video.player.PlayerActivity;
import com.archos.mediacenter.video.utils.ExternalPlayerResultListener;
import com.archos.mediacenter.video.utils.ExternalPlayerWithResultStarter;
import com.archos.mediacenter.video.utils.PlayUtils;
import com.archos.mediacenter.video.utils.SubtitlesDownloaderActivity2;
import com.archos.mediacenter.video.utils.SubtitlesWizardActivity;
import com.archos.mediacenter.video.utils.VideoUtils;
import com.archos.mediaprovider.video.VideoStore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import httpimage.HttpImageManager;

public abstract class BrowserByVideoObjects extends Browser implements CommonPresenter.ExtendedClickListener, ExternalPlayerWithResultStarter {

    private static final Logger log = LoggerFactory.getLogger(BrowserByVideoObjects.class);

    private static final int PLAY_ACTIVITY_REQUEST_CODE = 780;
    protected AdapterByVideoObjectsInterface mAdapterByVideoObjects;

    private final ActivityResultLauncher<Intent> playLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> ExternalPlayerResultListener.getInstance().onActivityResult(
                    PLAY_ACTIVITY_REQUEST_CODE, result.getResultCode(), result.getData()));

    protected final ActivityResultLauncher<Intent> infoLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> onInfoActivityResult(result.getResultCode(), result.getData()));

    protected void onInfoActivityResult(int resultCode, Intent data) {
        // default: no-op; subclasses may override
    }

    @Override
    protected void postBindAdapter() {
        super.postBindAdapter();

        mAdapterByVideoObjects = (AdapterByVideoObjectsInterface) mBrowserAdapter;
    }

    public Uri getRealPathUriFromPosition(int position){
        return Uri.parse(getFilePath(position));
    }

    @Override
    public String getFilePath(int pos){
        return mAdapterByVideoObjects.getVideoItem(pos).getFilePath();
    }

    public void displayInfo(int position){
        Video video = mAdapterByVideoObjects.getVideoItem(position);
        int firstFilePosition = getFirstFilePosition();
        ArrayList<Uri> urlList = new ArrayList<>();
        int j =0;
        int finalPos = 0;
        for (int i=position- VideoInfoActivity.MAX_VIDEO/2<firstFilePosition?firstFilePosition:position-VideoInfoActivity.MAX_VIDEO/2;i<getFileSize()+firstFilePosition;i++, j++) {
            urlList.add(j,getRealPathUriFromPosition(i));

            if(i == position)
                finalPos = j;
            if(j>VideoInfoActivity.MAX_VIDEO)
                break;
        }
        VideoInfoActivity.startInstance(infoLauncher, getActivity(), video, finalPos, urlList, -1, shouldForceVideoSelection(), getPlaylistId());
    }

    protected long getPlaylistId(){
        return -1;
    }

    protected boolean shouldForceVideoSelection() {
        return false;
    }

    /** Position of the video in the adapter for a list position (lists with a header override this). */
    protected int popupPosition(int listPosition) {
        return listPosition;
    }

    /** Long press on a video: small popup with Fetch meta / Delete Video (replaces the long context menu). */
    @Override
    public boolean onItemLongClick(android.widget.AdapterView parent, final View v, final int position, long id) {
        if (super.onItemLongClick(parent, v, position, id)) return true;
        if (!isItemClickable(position) || getActivity() == null) return false;
        final int pos = popupPosition(position);
        if (pos < 0) return false;
        final Video video;
        try {
            video = mAdapterByVideoObjects.getVideoItem(pos);
        } catch (RuntimeException e) {      // a row that is not a video (season, header...)
            return false;
        }
        if (video == null) return false;
        androidx.appcompat.widget.PopupMenu menu = new androidx.appcompat.widget.PopupMenu(requireActivity(), v);
        menu.getMenu().add(0, 1, 0, R.string.home_poster_fetch_meta);
        final boolean canDelete = video.getFileUri() != null && video.locationSupportsDelete()
                && !FileUtils.isSlowRemote(Uri.parse(video.getFilePath()));
        if (canDelete) menu.getMenu().add(0, 2, 1, R.string.home_poster_delete_video);
        menu.getMenu().add(0, 3, 2, R.string.cast_on_tv);
        menu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 3) {
                com.archos.mediacenter.video.browser.dlna.DlnaCastActivity.start(requireActivity(), video);
            } else if (item.getItemId() == 1) {
                if (video instanceof Movie || video instanceof Episode) {
                    com.archos.mediacenter.video.utils.PhoneMetadataRefresh.start(requireActivity(), video, v,
                            this::refresh);
                } else {
                    Intent intent = new Intent(getActivity(), com.archos.mediacenter.video.info.VideoInfoScraperActivity.class);
                    intent.putExtra(com.archos.mediacenter.video.info.VideoInfoScraperActivity.EXTRA_VIDEO, video);
                    startActivity(intent);
                }
            } else {
                List<Uri> toDelete = new ArrayList<>();
                toDelete.add(getRealPathUriFromPosition(pos));
                mDeletedPosition = pos;
                showConfirmDeleteDialog(false, toDelete);
            }
            return true;
        });
        menu.show();
        return true;
    }

    // This will display the menu with enabled actions for the file.
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        AdapterContextMenuInfo info;
        try {
            info = (AdapterContextMenuInfo) menuInfo;
        } catch (ClassCastException e) {
            log.error("onCreateContextMenu: bad menuInfo", e);
            return;
        }
        // This can be null sometimes, don't crash...
        if (info == null) {
            log.error("onCreateContextMenu: bad menuInfo");
            return;
        }

        final int position = info.position;
        final Video video = mAdapterByVideoObjects.getVideoItem(position);


        if (!isItemClickable(position)) {
            return;
        }
        if(video instanceof Episode){
            menu.setHeaderTitle(((Episode) video).getShowName()+": "+video.getName());
        }
        else
             menu.setHeaderTitle(video.getName());
        String entryPath = video.getFilePath();

        final int resumePosition = video.getResumeMs();
        final boolean resume = resumePosition > 0;
        final boolean delete = !FileUtils.isSlowRemote(Uri.parse(entryPath)) && video.locationSupportsDelete();
        final boolean isNetwork = !FileUtils.isLocal(video.getFileUri());
        menu.add(0, R.string.play_from_beginning, 0, R.string.play_selection);
        if (resume && resumePosition != PlayerActivity.LAST_POSITION_END) {
            menu.findItem(R.string.play_from_beginning).setTitle(R.string.play_from_beginning);
            String resumeString = mContext.getString(R.string.resume) + " (" + MediaUtils.formatTime(resumePosition) + ")";
            menu.add(0, R.string.resume, 0, resumeString);
        }

        if (delete)
            menu.add(0, R.string.delete, 0, R.string.delete);
        if (resume)
            menu.add(0, R.string.delete_resume, 0, R.string.delete_resume);

        menu.add(0, R.string.info, 0, R.string.info);
        if(!(video instanceof NonIndexedVideo)) {
            if (resumePosition != PlayerActivity.LAST_POSITION_END)
                menu.add(0, R.string.mark_as_watched, 0, R.string.mark_as_watched);
            else
                menu.add(0, R.string.mark_as_not_watched, 0, R.string.mark_as_not_watched);

        }
        final int f_position = position;
        final Activity activity = getActivity();
        // Subtitles wizard
        if(!isNetwork)
            menu.add(R.string.get_subtitles_on_drive).setOnMenuItemClickListener(
                    new OnMenuItemClickListener() {
                        public boolean onMenuItemClick(MenuItem item) {
                            Intent intent = new Intent(Intent.ACTION_MAIN);
                            intent.setClass(mContext, SubtitlesWizardActivity.class);
                            intent.setData(video.getFileUri());
                            activity.startActivity(intent);
                            return true;
                        }
                    });


        // Subloader
        menu.add(0, R.string.get_subtitles_online, 0, R.string.get_subtitles_online);

        if(video.hasScraperData()){
            menu.add(0, R.string.add_to_list, 0, R.string.add_to_list);

        }

        // Propose to remove from DB the files that are indexed
        if (video.getId()>0) {
            menu.add(0, R.string.video_browser_unindex_file, 0, R.string.video_browser_unindex_file);
        }
        else
            menu.add(0, R.string.video_browser_index_file, 0, R.string.video_browser_index_file);
        if(isNetwork){
            menu.add(0, R.string.copy_on_device, 0, R.string.copy_on_device);

        }
    }

    public void startVideo(int video, int resume) {

    }
    @Override
    public void onItemClick(AdapterView parent, View v, int position, long id) {
        super.onItemClick(parent, v, position, id);
        if (mIsClickValid) {
            Object itemData = mBrowserAdapter.getItem(position);
            if (itemData instanceof Video) {
                // File
                displayInfo(position);
                //startVideo((Video) itemData, PlayerActivity.RESUME_FROM_LAST_POS);
            }
        }
    }

    public static void setPresenters(Activity activity, CommonPresenter.ExtendedClickListener listener, PresenterAdapterInterface adapterInterface, int viewMode){
        CustomApplication application = (CustomApplication) activity.getApplication();
        HttpImageManager imageManager = application.getHttpImageManager();
        if(viewMode== VideoUtils.VIEW_MODE_LIST) {
            adapterInterface.setPresenter(Video.class, new VideoListPresenter(activity, listener,imageManager));
        }
        else if (viewMode == VideoUtils.VIEW_MODE_GRID_SHORT){
            adapterInterface.setPresenter(Video.class, new VideoGridShortPresenter(activity, listener, imageManager));

        }
        else if(viewMode==VideoUtils.VIEW_MODE_DETAILS){
            adapterInterface.setPresenter(NonIndexedVideo.class, new VideoListPresenter(activity, listener,imageManager));
            adapterInterface.setPresenter(Video.class, new VideoListPresenter(activity, listener,imageManager));
            adapterInterface.setPresenter(Episode.class, new ScrapedVideoDetailedPresenter(activity, listener,imageManager));
            adapterInterface.setPresenter(Movie.class, new ScrapedVideoDetailedPresenter(activity, listener,imageManager));
        }
        else {
            adapterInterface.setPresenter(Video.class, new VideoGridPresenter(activity, listener,imageManager));
        }
    }

    public void startVideo(Video video, int resume) {
        PlayUtils.startVideo(getActivity(),
                video,
                resume,
                true, -1, this, -1);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        boolean ret = true;
        int index = item.getItemId();
        AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
        Video video = mAdapterByVideoObjects.getVideoItem(info.position);
        if (index == R.string.play_from_beginning) {
            startVideo(video, PlayerActivity.RESUME_NO);
        } else if (index == R.string.resume) {
            startVideo(video, PlayerActivity.RESUME_FROM_LAST_POS);
        } else if (index == R.string.info) {
            displayInfo(info.position);
        } else if (index == R.string.video_browser_index_file) {
            VideoStore.requestIndexing(video.getFileUri(), getActivity());
        } else if (index == R.string.delete_resume) {
            updateDbXml(info.position, UpdateDbXmlType.RESUME, -1);
            
        } else if (index == R.string.delete) {
            if (ArchosSettings.isDemoModeActive(getActivity())) {
                getActivity().startService(
                        new Intent(ArchosIntents.ACTION_DEMO_MODE_FEATURE_DISABLED));
            } else {
                List<Uri> toDelete = new ArrayList<>();
                toDelete.add(getRealPathUriFromPosition(info.position));
                mDeletedPosition = info.position;
                showConfirmDeleteDialog(false, toDelete);
            }
        } else if (index == R.string.mark_as_watched) {
            markAsRead(info.position, true, mPreferences.getBoolean(BrowserByNetwork.KEY_NETWORK_BOOKMARKS, true));
        } else if (index == R.string.mark_as_not_watched) {
            markAsNotRead(info.position, true, mPreferences.getBoolean(BrowserByNetwork.KEY_NETWORK_BOOKMARKS, true));
        } else if (index == R.string.get_subtitles_online) {
            Intent subIntent = new Intent(Intent.ACTION_MAIN);
            if (log.isDebugEnabled()) log.debug("onContextItemSelected: get_subtitles_online for {}", getRealPathUriFromPosition(info.position));
            subIntent.setClass(mContext, SubtitlesDownloaderActivity2.class);
            subIntent.putExtra(SubtitlesDownloaderActivity2.FILE_URL, getRealPathUriFromPosition(info.position).toString());
            getActivity().startActivity(subIntent);
        } else if (index == R.string.video_browser_unindex_file) {
            updateDbXml(info.position, UpdateDbXmlType.HIDE, 1);
        } else if (index == R.string.copy_on_device) {
            List<Uri> toCopy = new ArrayList<>();
            toCopy.add(video.getFileUri());
            startDownloadingVideo(toCopy);
        } else if (index == R.string.add_to_list) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(ListDialog.EXTRA_VIDEO, video);
            ListDialog dialog = new ListDialog();
            dialog.setArguments(bundle);
            dialog.show(getActivity().getSupportFragmentManager(), "list_dialog");
        } else {
            ret = super.onContextItemSelected(item);
            log.error("onContextItemSelected: unexpected default case! {}", index);
        }

        return ret;
    }




    @Override
    protected boolean updateDbXml(int position, UpdateDbXmlType type, int value) {
        boolean dbUpdated = false;
        Object item = mBrowserAdapter.getItem(position);
        long id = -1;
        if(item instanceof Video)
            id = ((Video)item).getId();
        if ( id != -1) {
            String whereR = VideoStore.Video.VideoColumns._ID + " = "
                    + (int) id;
            final ContentValues cvR = new ContentValues(1);
            String col;

            switch (type) {
                case HIDE:
                    col = VideoStore.Video.VideoColumns.ARCHOS_HIDDEN_BY_USER;
                    break;
                case BOOKMARK:
                    col = VideoStore.Video.VideoColumns.ARCHOS_BOOKMARK;
                    break;
                case RESUME:
                    col = VideoStore.Video.VideoColumns.BOOKMARK;
                    break;
                case WATCHED_STATUS:
                    col = VideoStore.Video.VideoColumns.ARCHOS_TRAKT_SEEN;
                    break;
                default:
                    return dbUpdated;
            }
            cvR.put(col, value);
            getActivity().getContentResolver().update(
                    VideoStore.Video.Media.EXTERNAL_CONTENT_URI, cvR, whereR, null);
            dbUpdated = true;
            VideoDbInfo info  = VideoDbInfo.fromId(getActivity().getContentResolver(),id );
            XmlDb xmlDb = XmlDb.getInstance();
            xmlDb.writeXmlRemote(info);
        }
        return dbUpdated;
    }

    @Override
    public Uri getUriFromPosition(int position) {
        return ((AdapterByVideoObjectsInterface)mBrowserAdapter).getVideoItem(position).getDbUri();
    }


    public void onExtendedClick(View image,Object v, int positionInAdapter){
        displayInfo(positionInAdapter);
    }


    @Override
    public void startActivityWithResultListener(Intent intent) {
        playLauncher.launch(intent);
    }
}
